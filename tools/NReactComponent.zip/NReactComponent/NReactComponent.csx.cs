﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

#if NETFX_CORE
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
#else
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
#endif

using NReact;

namespace $rootnamespace$
{
  // this partial class is generated to improve 
  // Visual Studio Edit/Debug/Code Nav experience.
  // Override all component methods, except Render here.
  public partial class $safeitemname$ : NComponent
  {
    
  }
}
